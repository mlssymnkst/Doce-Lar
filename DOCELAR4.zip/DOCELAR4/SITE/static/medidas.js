(function () {
  // Prefixo usado nas chaves do localStorage
  const STORAGE_PREFIX = 'doce_lar_input_';

  // Função auxiliar para montar chave
  function storageKey(id) {
    return STORAGE_PREFIX + id;
  }

  // Todos os campos
  const fields = Array.from(document.querySelectorAll('.form-grid .field'));

  fields.forEach((field, index) => {
    const input = field.querySelector('input[type="text"], input[type="search"], input:not([type])');
    const btnEdit = field.querySelector('.btn-icon.edit');
    const btnDelete = field.querySelector('.btn-icon.delete');

    if (!input) return;

    // garante id único no input (necessário para persistência)
    if (!input.id) {
      input.id = `doce_input_${String(index + 1).padStart(2, '0')}`;
    }

    const key = storageKey(input.id);

    // Carrega valor salvo (se existir)
    const saved = localStorage.getItem(key);
    if (saved !== null) {
      input.value = saved;
      input.dataset.origValue = saved;
    } else {
      input.dataset.origValue = input.value || '';
    }

    // estado inicial: somente leitura e sem interação
    input.setAttribute('readonly', 'readonly');
    input.style.pointerEvents = 'none';

    // Inicia edição (desbloqueia)
    function startEdit() {
      input.removeAttribute('readonly');
      input.style.pointerEvents = 'auto';
      input.focus();
      btnEdit.classList.add('editing');
      btnEdit.setAttribute('title', 'Salvar');
      // seleciona texto para facilitar edição
      try { input.select(); } catch (e) {}
    }

    // Finaliza edição: se save==true, grava no localStorage; se false reverte
    function finishEdit(save = true) {
      if (save) {
        // opcional: aqui você pode validar antes de salvar
        try {
          localStorage.setItem(key, input.value);
        } catch (e) {
          console.warn('Erro ao salvar no localStorage:', e);
        }
        input.dataset.origValue = input.value;
      } else {
        input.value = input.dataset.origValue || '';
      }

      input.setAttribute('readonly', 'readonly');
      input.style.pointerEvents = 'none';
      btnEdit.classList.remove('editing');
      btnEdit.setAttribute('title', 'Editar');
      input.blur();
    }

    // Toggle no clique do botão editar
    btnEdit?.addEventListener('click', function (ev) {
      ev.preventDefault();
      if (input.hasAttribute('readonly')) {
        startEdit();
      } else {
        finishEdit(true);
      }
    });

    // Enter salva, Escape cancela
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        finishEdit(true);
      } else if (ev.key === 'Escape') {
        ev.preventDefault();
        finishEdit(false);
      }
    });

    // Ao perder o foco, salva automaticamente (se estava em edição)
    input.addEventListener('blur', function () {
      if (!input.hasAttribute('readonly')) {
        finishEdit(true);
      }
    });

    // Exclusão: remove do DOM e do localStorage
    btnDelete?.addEventListener('click', function (e) {
      e.preventDefault();
      const confirmed = confirm('Remover este item?');
      if (!confirmed) return;
      // animação suave (se tiver classe .removing no CSS)
      field.classList.add('removing');
      // remove a chave relacionada
      try { localStorage.removeItem(key); } catch (err) {}
      setTimeout(() => field.remove(), 220);
    });

    // garantir ativação por teclado nos botões
    [btnEdit, btnDelete].forEach(btn => {
      if (!btn) return;
      btn.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.key === ' ') {
          ev.preventDefault();
          btn.click();
        }
      });
    });
  }); // end foreach
})();