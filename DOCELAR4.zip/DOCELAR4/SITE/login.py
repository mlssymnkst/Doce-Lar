from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import os

app = Flask(__name__)
app.secret_key = "troque_esta_chave_para_uma_secreta_e_forte"


# CONFIGURAÇÕES

UPLOAD_FOLDER = os.path.join('DADOS', 'PRODUTOS')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# DADOS FIXOS (sEM O BANCO AINDA)

USUARIO_CORRETO = "Luiz@1"
SENHA_CORRETA = "123"

PRODUCTS = [
    {"id": "coca", "name": "Coca-Cola", "img": "COCACOLA.jpeg", "stock": "below"},
    {"id": "farinha", "name": "Farinha de Trigo", "img": "FARINHA.jpeg", "stock": "normal"},
    {"id": "guarana", "name": "Guaraná Antarctica", "img": "GUARANA.jpeg", "stock": "below"},
    {"id": "leite", "name": "Leite", "img": "LEITE.jpeg", "stock": "above"},
    {"id": "agua", "name": "Água", "img": "AGUA.png", "stock": "above"},
    {"id": "nutella", "name": "Balde De Nutella", "img": "NUTELLA.png", "stock": "below"},
    {"id": "ovo", "name": "Ovo", "img": "OVO.png", "stock": "normal"},
    {"id": "suco", "name": "Suco", "img": "SUCO.png", "stock": "above"},
]


# FUNÇÕES AUXILIARES

def ensure_session_quantities():
    """Garante que o dicionário de quantidades existe na sessão."""
    if "quantities" not in session:
        session["quantities"] = {p["id"]: 1 for p in PRODUCTS}


@app.before_request
def log_request():
    print("REQUEST PATH:", request.path)


# LOGIN

@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    mensagem = ""
    if request.method == "POST":
        usuario = request.form.get("email", "")
        senha = request.form.get("senha", "")

        if usuario == USUARIO_CORRETO and senha == SENHA_CORRETA:
            ensure_session_quantities()
            return redirect(url_for("index"))
        else:
            mensagem = "Usuário ou senha incorretos. Tente novamente."

    return render_template("tela_login.html", mensagem=mensagem)


# HOME

@app.route("/home")
def index():
    ensure_session_quantities()
    return render_template("home.html", products=PRODUCTS, quantities=session["quantities"])

@app.route("/update", methods=["POST"])
def update():
    ensure_session_quantities()
    quantities = session["quantities"]

    product_id = request.form.get("product_id")
    action = request.form.get("action")

    if product_id not in quantities:
        return jsonify(success=False)

    current = int(quantities[product_id])

    if action == "mais":
        current += 1
    elif action == "menos":
        current = max(0, current - 1)

    quantities[product_id] = current
    session["quantities"] = quantities

    return jsonify(success=True, quantity=current)


# CADASTRO DE INSUMOS

@app.route("/cadastro_insumos")
def cadastro_insumos():
    return render_template("cadastro_insumos.html")

@app.route("/salvar_insumo", methods=["POST"])
def salvar_insumo():
    nome = request.form.get("nome")
    categoria = request.form.get("categoria")
    descricao = request.form.get("descricao")
    quantidade = request.form.get("quantidade")
    unidade = request.form.get("unidade")
    foto = request.files.get("foto_produto")

    nome_arquivo = None
    if foto and foto.filename != "":
        nome_arquivo = foto.filename
        caminho = os.path.join(app.config['UPLOAD_FOLDER'], nome_arquivo)
        foto.save(caminho)

    print("\n=== NOVO PRODUTO CADASTRADO ===")
    print(f"Nome: {nome}")
    print(f"Categoria: {categoria}")
    print(f"Descrição: {descricao}")
    print(f"Quantidade: {quantidade}")
    print(f"Unidade: {unidade}")
    print(f"Imagem: {nome_arquivo}")
    print("===============================")

    return redirect(url_for("cadastro_insumos"))


# MEDIDAS

@app.route("/medidas")
def medidas():
    return render_template("medidas.html")


# REMOVER PRODUTO

@app.route("/remover_produto")
def remover_produto():
    return render_template("remover.html")


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
if __name__ == "__main__":
    print("Rodando em http://127.0.0.1:5000")
    app.run(debug=True)
