from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Credenciais de exemplo 
USUARIO_CORRETO = "Luiz@1"
SENHA_CORRETA = "123"

@app.before_request
def log_request():
    print("REQUEST PATH:", request.path)


@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    mensagem = ""
    if request.method == "POST":
        usuario = request.form.get("email", "")
        senha = request.form.get("senha", "")

        if usuario == USUARIO_CORRETO and senha == SENHA_CORRETA:
            return redirect(url_for("teste"))
        else:
            mensagem = "Usuário ou senha incorretos. Tente novamente."

    return render_template("tela_login.html", mensagem=mensagem)


@app.route("/teste")
@app.route("/teste.html")
def teste():
    return render_template("teste.html")

if __name__ == "__main__":
    print("Rodando em http://127.0.0.1:5000")
    app.run(debug=True)
