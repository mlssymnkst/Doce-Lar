document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".qty-control").forEach(control => {
    const productId = control.dataset.product;
    const input = control.querySelector(".qty-input");
    const btnMais = control.querySelector(".mais");
    const btnMenos = control.querySelector(".menos");

    if (!productId || !input || !btnMais || !btnMenos) return;

    // Bloqueia edição manual no input
    input.setAttribute("readonly", true);
    input.addEventListener("keydown", e => e.preventDefault()); // impede qualquer digitação
    input.addEventListener("paste", e => e.preventDefault()); // impede colar valores

    btnMais.type = "button";
    btnMenos.type = "button";

    const updateQuantity = async (action, value = null) => {
      btnMais.disabled = true;
      btnMenos.disabled = true;

      try {
        const formData = new FormData();
        formData.append("product_id", productId);
        formData.append("action", action);
        if (value !== null) formData.append("value", String(value));

        const res = await fetch("/update", {
          method: "POST",
          body: formData,
          credentials: "same-origin"
        });

        if (!res.ok) return;

        const data = await res.json();
        if (data && data.success) {
          input.value = data.quantity;

          const badge = control.closest(".card").querySelector(".stock-badge");
          if (data.quantity < data.qtde_min) badge.textContent = "Abaixo do estoque";
          else if (data.quantity > data.qtde_max) badge.textContent = "Acima do estoque";
          else badge.textContent = "Quantidade do Estoque";

          channel.postMessage({
            type: "quantity_changed",
            product_id: productId,
            quantity: data.quantity
          });
        }
      } finally {
        btnMais.disabled = false;
        btnMenos.disabled = false;
      }
    };

    btnMais.addEventListener("click", () => updateQuantity("mais"));
    btnMenos.addEventListener("click", () => updateQuantity("menos"));
  });

  // BroadcastChannel para sincronização
  channel.addEventListener("message", (ev) => {
    const msg = ev.data;
    if (!msg || !msg.type) return;

    if (msg.type === "product_deleted") {
      const card = document.querySelector(`.card[data-product="${msg.product_id}"]`);
      if (card) card.remove();
    } else if (msg.type === "quantity_changed") {
      const control = document.querySelector(`.qty-control[data-product="${msg.product_id}"]`);
      if (control) {
        const input = control.querySelector(".qty-input");
        if (input) input.value = msg.quantity;

        const badge = control.closest(".card").querySelector(".stock-badge");
        if (msg.quantity < control.dataset.qtde_min) badge.textContent = "Abaixo do estoque";
        else if (msg.quantity > control.dataset.qtde_max) badge.textContent = "Acima do estoque";
        else badge.textContent = "Quantidade do Estoque";
      }
    }
  });
});
