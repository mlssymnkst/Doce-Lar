document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".qty-control").forEach(control => {
    const productId = control.dataset.product;
    const input = control.querySelector(".qty-input");
    const btnMais = control.querySelector(".mais");
    const btnMenos = control.querySelector(".menos");

    const updateQuantity = (action) => {
      const formData = new FormData();
      formData.append("product_id", productId);
      formData.append("action", action);

      fetch("/update", {
        method: "POST",
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          input.value = data.quantity;
        }
      });
    };

    btnMais.addEventListener("click", () => updateQuantity("mais"));
    btnMenos.addEventListener("click", () => updateQuantity("menos"));
  });
});
