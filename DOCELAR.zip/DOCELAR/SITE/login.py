from flask import Flask, render_template, request, redirect, url_for, jsonify, send_from_directory, session
import psycopg2
from psycopg2.extras import RealDictCursor
import os
from datetime import date
import time
import unicodedata
import re

app = Flask(__name__)
app.secret_key = "troque_esta_chave_para_uma_secreta_e_forte"

# CONFIGURAÇÕES - caminho absoluto para a pasta de produtos
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['PRODUTOS_FOLDER'] = os.path.join(BASE_DIR, 'DADOS', 'PRODUTOS')


# ---------- Helpers ----------
def normalize_name(s: str) -> str:
    """Remove acentos, normaliza para minúsculas e substitui sequências não alfanuméricas por underscore."""
    if not s:
        return ""
    s = unicodedata.normalize('NFKD', s).encode('ASCII', 'ignore').decode('ASCII')
    s = s.lower()
    s = re.sub(r'[^a-z0-9]+', '_', s)
    s = re.sub(r'_+', '_', s).strip('_')
    return s

# COENXÃO COM O BANCO 
def get_connection():
    return psycopg2.connect(
        host="localhost",
        port=5432,
        database="docelar",
        user="postgres",
        password=1234
    )

# BOTÃO DE MAIS E MENOS
def ensure_session_quantities():
    """Garante que o dicionário de quantidades existe na sessão."""
    if "quantities" not in session:
        session["quantities"] = {}

# PROCURA A IMG DO PRODUTO
def find_image_for_name(nome):
    """Procura imagem correspondente ao nome do produto nas pastas configuradas."""
    nome_norm = normalize_name(nome.strip())
    pasta_dados = app.config.get('PRODUTOS_FOLDER', os.path.join(app.root_path, "DADOS", "PRODUTOS"))
    pasta_static = os.path.join(app.static_folder or "static", "img")
    fallback = url_for("static", filename="img/sem_imagem.png")

    try:
        if os.path.isdir(pasta_dados):
            for arquivo in os.listdir(pasta_dados):
                arquivo_base, _ = os.path.splitext(arquivo)
                if normalize_name(arquivo_base).startswith(nome_norm):
                    return f"/produto_img/{arquivo}"

        if os.path.isdir(pasta_static):
            for arquivo in os.listdir(pasta_static):
                arquivo_base, _ = os.path.splitext(arquivo)
                if normalize_name(arquivo_base).startswith(nome_norm):
                    return url_for("static", filename=f"img/{arquivo}")

    except Exception as e:
        print("Erro buscando imagem:", e)

    return fallback


# ---------------------------------------------------------
# ROTAS
# ---------------------------------------------------------


#LOGIN
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    mensagem = ""
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        senha = request.form.get("senha", "").strip()

        if not email or not senha:
            mensagem = "Preencha e-mail e senha."
            return render_template("tela_login.html", mensagem=mensagem)

        conn = None
        cur = None
        try:
            conn = get_connection()
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("""
                SELECT cod_usuario, nome_usuario, email, senha_usu
                FROM usuarios
                WHERE email = %s
                LIMIT 1
            """, (email,))
            row = cur.fetchone()

            if not row:
                mensagem = "E-mail não cadastrado."
            else:
                senha_db = row["senha_usu"]
                if senha == senha_db:  # adapte para hash se necessário
                    ensure_session_quantities()
                    session["user"] = {
                        "cod_usuario": row["cod_usuario"],
                        "nome_usuario": row["nome_usuario"],
                        "email": row["email"]
                    }
                    return redirect(url_for("index"))
                else:
                    mensagem = "Senha incorreta."

        except Exception as e:
            mensagem = f"Erro no servidor: {str(e)}"
            print("Erro em /login:", e)
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

    return render_template("tela_login.html", mensagem=mensagem)

# HONE
@app.route("/home")
def index():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
        SELECT cod_insumo, nome_insumo, qtde_atual, qtde_min, qtde_max
        FROM insumos
        WHERE qtde_atual > 0
        ORDER BY nome_insumo;
""")
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        print("Erro ao buscar insumos:", e)
        rows = []

    produtos = []
    ensure_session_quantities()

    for cod, nome, qtde, qtde_min, qtde_max in rows:
        try:
            qtde_int = int(qtde)
        except:
            qtde_int = 0
        try:
            qtde_min_int = int(qtde_min)
        except:
            qtde_min_int = 1
        try:
            qtde_max_int = int(qtde_max)
        except:
            qtde_max_int = 100

        if qtde_int < qtde_min_int:
            stock = "below"
        elif qtde_int > qtde_max_int:
            stock = "above"
        else:
            stock = "normal"

        # salva a quantidade atual na session
        session["quantities"][str(cod)] = qtde_int

        img_url = find_image_for_name(nome)

        produtos.append({
            "id": str(cod),
            "name": nome,
            "img": img_url,
            "stock": stock
        })

    session.modified = True
    return render_template("home.html", products=produtos, quantities=session["quantities"])

#UPDATE HOME
@app.route("/update", methods=["POST"])
def update_quantity():
    product_id = request.form.get("product_id")
    action = request.form.get("action")
    value = request.form.get("value", None)

    if not product_id or not action:
        return jsonify({"success": False, "error": "Parâmetros inválidos."}), 400

    try:
        prod_id_int = int(product_id)
    except:
        return jsonify({"success": False, "error": "product_id inválido."}), 400

    conn = None
    cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        # obter quantidade atual do banco (lock row)
        try:
            cur.execute("SELECT qtde_atual FROM insumos WHERE cod_insumo = %s FOR UPDATE;", (prod_id_int,))
            row = cur.fetchone()
            current = int(row[0]) if row and row[0] is not None else int(session.get("quantities", {}).get(str(prod_id_int), 0))
        except Exception:
            current = int(session.get("quantities", {}).get(str(prod_id_int), 0))

        if action == "mais":
            new_qty = current + 1
        elif action == "menos":
            new_qty = max(0, current - 1)
        elif action == "set":
            try:
                new_qty = max(0, int(value))
            except:
                return jsonify({"success": False, "error": "valor inválido para set."}), 400
        else:
            return jsonify({"success": False, "error": "ação desconhecida."}), 400

        cur.execute("UPDATE insumos SET qtde_atual = %s WHERE cod_insumo = %s RETURNING qtde_atual;", (new_qty, prod_id_int))
        result = cur.fetchone()
        conn.commit()

        final_qty = int(result[0]) if result and result[0] is not None else new_qty

        ensure_session_quantities()
        session["quantities"][str(prod_id_int)] = final_qty
        session.modified = True

        return jsonify({"success": True, "quantity": final_qty})

    except Exception as e:
        print("Erro em /update:", e)
        try:
            if conn:
                conn.rollback()
        except:
            pass
        return jsonify({"success": False, "error": "Erro interno do servidor."}), 500
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

# ADICIONAR PRODUTO
@app.route("/cadastro_insumos")
def cadastro_insumos():
    return render_template("cadastro_insumos.html")


@app.route("/salvar_insumo", methods=["POST"])
def salvar_insumo():
    nome = request.form.get("nome")
    quantidade = request.form.get("quantidade") or 0
    valor = request.form.get("valor") or 0
    unidade = request.form.get("unidade")
    validade = request.form.get("validade")
    categoria = request.form.get("categoria")
    descricao = request.form.get("descricao")
    foto = request.files.get("foto_produto")

    categoria_dict = {
        "1": "Ingredientes",
        "2": "Embalagens",
        "3": "Limpeza",
        "4": "Complementos",
        "5": "Consumíveis"
    }
    tipo_text = categoria_dict.get(categoria, "Outro")

    pasta_externa = os.path.join(app.root_path, "DADOS", "PRODUTOS")
    os.makedirs(pasta_externa, exist_ok=True)

    nome_arquivo = None
    if foto and foto.filename:
        nome_formatado = normalize_name(nome)
        _, ext = os.path.splitext(foto.filename)
        nome_arquivo = f"{nome_formatado}_{int(time.time())}{ext}"
        caminho = os.path.join(pasta_externa, nome_arquivo)
        foto.save(caminho)
        print(f"Imagem salva em: {caminho}")

    try:
        conn = get_connection()
        cur = conn.cursor()
        cod_usuario = session.get("user", {}).get("cod_usuario", 1)

        cur.execute("""
            INSERT INTO insumos
            (nome_insumo, tipo, descricao, qtde_min, qtde_max, qtde_atual, valor_insumo,
            data_validade, cod_medida, cod_usuario, cod_categ)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
        """, (
            nome, tipo_text, descricao, 1, 100, quantidade, valor,
            validade, unidade, cod_usuario, categoria
        ))

        conn.commit()
        cur.close()
        conn.close()

        print(f"Insumo '{nome}' salvo com sucesso!")
        return redirect(url_for("index"))

    except Exception as e:
        print("Erro ao salvar insumo:", e)
        return jsonify({"erro": str(e)}), 500

# CAMINHO PARA IMAGEM NO ADD PORDUTO
@app.route("/produto_img/<path:filename>")
def produto_img(filename):
    caminho_produtos = os.path.join(app.root_path, "DADOS", "PRODUTOS")
    return send_from_directory(caminho_produtos, filename)

#MEDIDAS
@app.route("/medidas")
def medidas():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT cod_insumo, nome_insumo, qtde_atual FROM insumos WHERE qtde_atual > 0 ORDER BY nome_insumo;")

        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        print("Erro ao buscar insumos:", e)
        rows = []

    produtos = []
    for cod, nome, qtde in rows:
        produtos.append({
            "id": cod,
            "name": nome,
            "quantity": qtde
        })

    return render_template("medidas.html", products=produtos)

#MEDIDAS PEGANDO O MOVIMENTO DO ESTOQUE 
@app.route("/registrar_movimento", methods=["POST"])
def registrar_movimento():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"success": False, "error": "JSON inválido"}), 400

    cod_insumo = data.get("cod_insumo")
    tipo_mov = data.get("tipo_mov")
    cod_usuario = data.get("cod_usuario") or 1
    qtde = data.get("qtde")
    motivo = data.get("motivo", "")

    try:
        cod_insumo = int(cod_insumo)
        qtde = int(qtde)
    except Exception:
        return jsonify({"success": False, "error": "cod_insumo/qtde inválidos"}), 400

    if tipo_mov not in ["Entrada", "Saida"]:
        return jsonify({"success": False, "error": "tipo_mov inválido"}), 400

    conn = None
    cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("SELECT qtde_atual FROM insumos WHERE cod_insumo = %s FOR UPDATE;", (cod_insumo,))
        row = cur.fetchone()
        if not row:
            conn.rollback()
            return jsonify({"success": False, "error": "Insumo não encontrado"}), 404

        qtde_atual = int(row[0]) if row[0] is not None else 0

        if tipo_mov == "Entrada":
            nova_qtde = qtde_atual + qtde
        else:
            nova_qtde = max(0, qtde_atual - qtde)

        cur.execute(
            "INSERT INTO estoque_movimento (tipo_mov, cod_usuario, cod_insumo, qtde, motivo, data_mov) "
            "VALUES (%s, %s, %s, %s, %s, %s) RETURNING cod_mov;",
            (tipo_mov, cod_usuario, cod_insumo, qtde, motivo[:250], date.today())
        )
        mov_id = cur.fetchone()[0]

        cur.execute("UPDATE insumos SET qtde_atual = %s WHERE cod_insumo = %s RETURNING qtde_atual;", (nova_qtde, cod_insumo))
        updated = cur.fetchone()
        conn.commit()

        final_qtde = int(updated[0]) if updated and updated[0] is not None else nova_qtde

        ensure_session_quantities()
        session["quantities"][str(cod_insumo)] = final_qtde
        session.modified = True

        return jsonify({
            "success": True,
            "mov_id": mov_id,
            "qtde_atual": final_qtde,
            "mensagem": f"Movimento registrado. Qtde atual: {final_qtde}"
        })

    except Exception as e:
        print("Erro em /registrar_movimento:", e)
        try:
            if conn:
                conn.rollback()
        except:
            pass
        return jsonify({"success": False, "error": "Erro interno do servidor."}), 500
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


@app.route("/delete_product", methods=["POST"])
def delete_product():
    product_id = request.form.get("product_id")
    motivo_original = request.form.get("motivo", "").strip().lower()

    if not product_id:
        return jsonify({"success": False, "error": "product_id ausente"}), 400
    try:
        pid = int(product_id)
    except:
        return jsonify({"success": False, "error": "product_id inválido"}), 400

    # ---- MAPEAMENTO DO MOTIVO ----
    def map_motivo(m):
        if any(x in m for x in ["defeito", "estrag", "quebrada", "quebrou"]):
            return "DEFEITO"
        if any(x in m for x in ["avaria", "amassado", "dano"]):
            return "AVARIA"
        if any(x in m for x in ["ajuste", "invent", "estoque"]):
            return "AJUSTE DE INVENTARIO"
        if any(x in m for x in ["perda", "sumiu", "extravio"]):
            return "PERDA"
        return "PERDA"

    motivo_final = map_motivo(motivo_original)

    conn = None
    cur = None

    try:
        conn = get_connection()
        cur = conn.cursor()

        user_id = session.get("user", {}).get("cod_usuario", 1)

        # pega dados do produto
        cur.execute("SELECT nome_insumo, qtde_atual FROM insumos WHERE cod_insumo = %s FOR UPDATE;", (pid,))
        row = cur.fetchone()
        if not row:
            conn.rollback()
            return jsonify({"success": False, "error": "Produto não encontrado"}), 404

        qtde_atual = int(row[1]) if row[1] is not None else 0
        qtde_mov = qtde_atual if qtde_atual > 0 else 1

        # grava movimento obrigatório
        cur.execute("""
            INSERT INTO estoque_movimento
            (tipo_mov, cod_usuario, cod_insumo, qtde, motivo, data_mov)
            VALUES ('Saida', %s, %s, %s, %s, %s)
            RETURNING cod_mov;
        """, (user_id, pid, qtde_mov, motivo_final, date.today()))
        mov_id = cur.fetchone()[0]

        # DESATIVAR PRODUTO = zerar estoque 
        cur.execute("""
            UPDATE insumos
            SET qtde_atual = 0
            WHERE cod_insumo = %s
            RETURNING cod_insumo;
        """, (pid,))
        updated = cur.fetchone()

        if not updated:
            conn.rollback()
            return jsonify({"success": False, "error": "Falha ao marcar produto"}), 500

        conn.commit()

        # remove da sessão
        ensure_session_quantities()
        session["quantities"].pop(str(pid), None)
        session.modified = True

        return jsonify({
            "success": True,
            "product_id": pid,
            "mov_id": mov_id,
            "motivo_final_usado": motivo_final
        })

    except Exception as e:
        print("Erro em /delete_product:", e)
        try:
            if conn:
                conn.rollback()
        except:
            pass
        return jsonify({"success": False, "error": "Erro interno do servidor."}), 500
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()




# TELA REMOVER PRDOUTO
@app.route("/remover_produto")
def remover_produto():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
    SELECT cod_insumo, nome_insumo, qtde_atual, qtde_min, qtde_max
    FROM insumos
    WHERE qtde_atual > 0
    ORDER BY nome_insumo;
""")

        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        print("Erro ao buscar insumos:", e)
        rows = []

    produtos = []
    for cod, nome, qtde, qtde_min, qtde_max in rows:
        try: qtde_int = int(qtde)
        except: qtde_int = 0
        try: qtde_min_int = int(qtde_min)
        except: qtde_min_int = 1
        try: qtde_max_int = int(qtde_max)
        except: qtde_max_int = 100

        if qtde_int < qtde_min_int:
            stock = "below"
        elif qtde_int > qtde_max_int:
            stock = "above"
        else:
            stock = "normal"

        img_url = find_image_for_name(nome)

        produtos.append({
            "id": str(cod),
            "name": nome,
            "img": img_url,
            "qtde": qtde_int,
            "stock": stock
        })

    return render_template("remover.html", products=produtos)


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
if __name__ == "__main__":
    print("Rodando em http://127.0.0.1:5000")
    app.run(debug=True)
