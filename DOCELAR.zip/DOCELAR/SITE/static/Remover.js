document.addEventListener("DOMContentLoaded", () => {
  const channel = new BroadcastChannel("doce_lar_updates");

  // Faz fetch para deletar produto no servidor
  const deleteOnServer = async (productId) => {
    try {
      const form = new FormData();
      form.append("product_id", productId);

      const res = await fetch("/delete_product", {
        method: "POST",
        body: form,
        credentials: "same-origin"
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      return data;
    } catch (err) {
      console.error("Erro ao deletar no servidor:", err);
      return { success: false, error: err.message };
    }
  };

  // Faz fetch para atualizar quantidade no servidor (usa a mesma rota /update)
  const setQuantityOnServer = async (productId, value) => {
    try {
      const form = new FormData();
      form.append("product_id", productId);
      form.append("action", "set");
      form.append("value", String(value));

      const res = await fetch("/update", {
        method: "POST",
        body: form,
        credentials: "same-origin"
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      return data;
    } catch (err) {
      console.error("Erro ao setar quantidade no servidor:", err);
      return { success: false, error: err.message };
    }
  };

  // Habilita edição ao clicar em editar, e ao blur envia para o servidor
  document.querySelectorAll(".btn-icon.edit").forEach(editBtn => {
    editBtn.addEventListener("click", () => {
      const card = editBtn.closest(".card");
      if (!card) return;

      const inputQty = card.querySelector(".qty-input");
      const productId = card.dataset.product || card.querySelector(".product-title").dataset.id;

      if (!inputQty) return;

      inputQty.removeAttribute("readonly");
      inputQty.focus();
      inputQty.style.borderColor = "#7a4a86";

      // Ao finalizar edição, envia para o servidor e notifica outras abas
      inputQty.addEventListener("blur", async () => {
        inputQty.setAttribute("readonly", "readonly");
        inputQty.style.borderColor = "";

        const numeric = parseInt(inputQty.value || "0", 10);
        const resp = await setQuantityOnServer(productId, numeric);

        if (resp && resp.success) {
          // atualiza input com valor retornado pelo servidor (evita dessincronia)
          inputQty.value = resp.quantity;

          // notifica outras abas/páginas
          channel.postMessage({
            type: "quantity_changed",
            product_id: String(productId),
            quantity: resp.quantity
          });
        } else {
          alert("Não foi possível salvar a alteração. Tente novamente.");
        }
      }, { once: true });
    });
  });

  // Botão excluir: chama servidor, remove card e notifica outras abas
  document.querySelectorAll(".btn-icon.delete").forEach(deleteBtn => {
    deleteBtn.addEventListener("click", async () => {
      const card = deleteBtn.closest(".card");
      if (!card) return;

      const productId = card.dataset.product || card.querySelector(".product-title").dataset.id;
      const productName = card.querySelector(".product-title").textContent.trim();

      // confirmação simples
      if (!confirm(`Deseja realmente excluir "${productName}" do estoque? Esta ação é irreversível.`)) return;

      // chama backend
      const resp = await deleteOnServer(productId);
      if (resp && resp.success) {
        // remove do DOM
        card.remove();

        // notifica outras abas/páginas pra remover também
        channel.postMessage({
          type: "product_deleted",
          product_id: String(productId)
        });

        // opcional: feedback ao usuário
        alert(`Produto "${productName}" removido com sucesso.`);
      } else {
        alert("Falha ao excluir o produto no servidor.");
      }
    });
  });

  // Ao receber notificações de outras abas, atualiza DOM local (caso necessário)
  channel.addEventListener("message", (ev) => {
    const msg = ev.data;
    if (!msg || !msg.type) return;

    if (msg.type === "product_deleted") {
      // remove card se existir
      const card = document.querySelector(`.card[data-product="${msg.product_id}"]`);
      if (card) card.remove();
    } else if (msg.type === "quantity_changed") {
      // atualiza input se existir
      const card = document.querySelector(`.card[data-product="${msg.product_id}"]`);
      if (card) {
        const input = card.querySelector(".qty-input");
        if (input) input.value = msg.quantity;
      }
    }
  });

  // Carregamento inicial: opcional (pode ser usado para sincronizar localStorage/etc)
});
