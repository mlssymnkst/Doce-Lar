document.addEventListener("DOMContentLoaded", () => {

  // Função para carregar os valores salvos no localStorage e aplicar nos inputs
  const loadQuantities = () => {
    document.querySelectorAll(".card").forEach(card => {
      const productTitle = card.querySelector(".product-title").textContent.trim();
      const inputQty = card.querySelector(".qty-input");

      const savedQty = localStorage.getItem(`qty_${productTitle}`);
      if (savedQty !== null && inputQty) {
        inputQty.value = savedQty;
      }
    });
  };

  // Função para salvar a quantidade em localStorage para um produto específico
  const saveQuantity = (productTitle, quantity) => {
    localStorage.setItem(`qty_${productTitle}`, quantity);
  };

  // Habilitar edição do input ao clicar em editar
  document.querySelectorAll(".btn-icon.edit").forEach(editBtn => {
    editBtn.addEventListener("click", () => {
      const card = editBtn.closest(".card");
      if (!card) return;

      const inputQty = card.querySelector(".qty-input");
      const productTitle = card.querySelector(".product-title").textContent.trim();

      if (!inputQty) return;

      // Remover atributo readonly para permitir digitação
      inputQty.removeAttribute("readonly");
      inputQty.focus();
      inputQty.style.borderColor = "#7a4a86";

      // Ao finalizar edição (quando o input perde o foco), salvar a quantidade e bloquear novamente
      inputQty.addEventListener("blur", () => {
        inputQty.setAttribute("readonly", "readonly");
        inputQty.style.borderColor = ""; // volta ao estilo original

        // Salvar no localStorage o valor alterado
        saveQuantity(productTitle, inputQty.value);
      }, { once: true }); // add o evento uma única vez
    });
  });

  // Botão excluir: remove card e limpa localStorage daquele produto
  document.querySelectorAll(".btn-icon.delete").forEach(deleteBtn => {
    deleteBtn.addEventListener("click", () => {
      const card = deleteBtn.closest(".card");
      if (!card) return;

      const productTitle = card.querySelector(".product-title").textContent.trim();

      card.remove();

      // Remove do localStorage
      localStorage.removeItem(`qty_${productTitle}`);
    });
  });

  // Carregar os valores salvos ao iniciar a página
  loadQuantities();
});
