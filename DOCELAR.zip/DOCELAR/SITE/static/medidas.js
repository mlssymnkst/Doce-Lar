document.addEventListener("DOMContentLoaded", () => {
  const fields = document.querySelectorAll(".form-grid .field");
  const channel = new BroadcastChannel("doce_lar_updates"); // canal de sincronização

  // Envia registro de movimento (Entrada / Saída) para o backend
  const enviarMovimento = async (payload) => {
    try {
      const res = await fetch("/registrar_movimento", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "same-origin"
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.error("Erro registrar_movimento:", err);
      return { success: false, error: err.message };
    }
  };

  // Deleta produto no servidor
  const deleteOnServer = async (productId) => {
    try {
      const form = new FormData();
      form.append("product_id", productId);
      const res = await fetch("/delete_product", {
        method: "POST",
        body: form,
        credentials: "same-origin"
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.error("Erro delete_product:", err);
      return { success: false, error: err.message };
    }
  };

  fields.forEach(field => {
    const input = field.querySelector("input");
    const btnEdit = field.querySelector(".btn-icon.edit");
    const btnDelete = field.querySelector(".btn-icon.delete");
    const codInsumo = field.dataset.codInsumo;

    // bloqueio inicial (como estava)
    input.setAttribute("readonly", true);
    input.style.pointerEvents = "none";

    btnEdit.addEventListener("click", async () => {
      // deixa editável por prompt / entrada direta
      input.removeAttribute("readonly");
      input.style.pointerEvents = "auto";
      input.focus();

      const novoValor = prompt(`Informe a nova quantidade de ${field.querySelector("label").innerText}:`, input.value);
      if (novoValor === null) {
        // usuário cancelou
        input.setAttribute("readonly", true);
        input.style.pointerEvents = "none";
        return;
      }

      // valida número (permite inteiros >= 0)
      const parsed = parseInt(novoValor.toString().replace(/\D/g, "") || "0", 10);
      if (isNaN(parsed) || parsed < 0) return alert("Quantidade inválida.");

      const motivo = prompt("Informe o motivo da alteração (ENTRADA ou PRODUCAO ou AJUSTE):");
      if (!motivo) return alert("Motivo obrigatório");

      // prepara payload padrão para registrar movimentação (tipo_mov: Entrada)
      const payload = {
        cod_insumo: codInsumo,
        tipo_mov: "Entrada",   // você pode usar Entrada/ Saida conforme sua lógica
        cod_usuario: 1,        // adaptar se tiver usuário logado
        qtde: parsed,
        motivo: motivo
      };

      // envia para o backend e espera retorno
      const resp = await enviarMovimento(payload);
      if (resp && resp.success) {
        // atualiza campo com valor final do banco (resp.qtde_atual)
        input.value = resp.qtde_atual;
        input.setAttribute("readonly", true);
        input.style.pointerEvents = "none";

        // notifica outras abas (home, remover) que a quantidade mudou
        channel.postMessage({
          type: "quantity_changed",
          product_id: String(codInsumo),
          quantity: resp.qtde_atual
        });

        alert(resp.mensagem || "Movimento registrado com sucesso.");
      } else {
        alert("Falha ao registrar movimento: " + (resp.error || "erro desconhecido"));
        input.setAttribute("readonly", true);
        input.style.pointerEvents = "none";
      }
    });

    btnDelete.addEventListener("click", async () => {
      const productName = field.querySelector("label").innerText;
      if (!confirm(`Deseja realmente excluir o produto "${productName}" do sistema? Esta ação é irreversível.`)) return;

      // opcional: pedir motivo para registro (aqui vamos usar /delete_product para realmente apagar)
      const motivo = prompt("Informe o motivo da exclusão (VENDA, AJUSTE, VALIDADE, PERDA, OUTRO):");
      if (!motivo) return alert("Motivo obrigatório");

      // primeiro, opcional: registrar uma saída no estoque (se quiser manter histórico)
      const valorAtual = parseInt(input.value || "0", 10);
      if (!isNaN(valorAtual) && valorAtual > 0) {
        // registra uma saída com motivo de exclusão para histórico
        await enviarMovimento({
          cod_insumo: codInsumo,
          tipo_mov: "Saida",
          cod_usuario: 1,
          qtde: valorAtual,
          motivo: `EXCLUSAO:${motivo}`
        });
        // ignoramos o retorno aqui — se falhar, ainda tentamos deletar, mas idealmente tratar retorno
      }

      // chama a rota de delete que remove o produto do DB
      const delResp = await deleteOnServer(codInsumo);
      if (delResp && delResp.success) {
        // remove do DOM
        field.remove();

        // notifica outras abas para remover o produto
        channel.postMessage({
          type: "product_deleted",
          product_id: String(codInsumo)
        });

        alert(`Produto "${productName}" removido com sucesso.`);
      } else {
        alert("Falha ao excluir produto: " + (delResp.error || "erro desconhecido"));
      }
    });
  });

  // opcional: listener para sincronizar se outra aba emitir mudança (p.ex. Home/Remover)
  channel.addEventListener("message", (ev) => {
    const msg = ev.data;
    if (!msg || !msg.type) return;

    if (msg.type === "product_deleted") {
      const f = document.querySelector(`.form-grid .field[data-cod-insumo="${msg.product_id}"]`);
      if (f) f.remove();
    } else if (msg.type === "quantity_changed") {
      const f = document.querySelector(`.form-grid .field[data-cod-insumo="${msg.product_id}"]`);
      if (f) {
        const inp = f.querySelector("input");
        if (inp) inp.value = msg.quantity;
      }
    }
  });
});
